''' Package for built-in selection operators '''

